<?php

$conn = mysqli_connect("localhost", "team4", "mercymonicadamilolaabisola", "mealville");
if(!$conn){
    echo "connection error:";
}
?>